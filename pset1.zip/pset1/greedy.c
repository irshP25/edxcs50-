/*greedy.c
    
    Author: Pooja Srivastava
    
    This file is a solution of the greedy algo problem from
    pset1 of CS50.
*/
#include<cs50.h>
#include<stdio.h>
#include<math.h>
int main()
{   int coins=0;
    float money;
    printf("O hai! How much change is owed? \n");
    money=get_float();
    while(money<0)
    {
     printf("How much change is owed? \n");
    money=get_float();
    printf("Money should greater than zero:\n");
    }
    int amount=round(money*100);
    while(amount>0)
    {
     if((amount-25)>=0)
     {amount=amount-25;coins++;}
     else if((amount-10)>=0){amount=amount-10;coins++;}
     else if((amount-5)>=0){amount=amount-5;coins++;}
    else if((amount-1)>=0){amount=amount-1;coins++;}
        
    }
    printf("%d\n",coins);}