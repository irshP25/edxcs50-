/*hello.c
    
    Author: Pooja Srivastava
    
    This file is a solution of the hello problem from
    pset1 of CS50.
*/
#include<cs50.h>
#include<stdio.h>
int main()
{
    printf("Hello, world!\n");
}