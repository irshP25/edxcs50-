/*mario.c
    
    Author: Pooja Srivastava
    
    This file is a solution of the mario pyramid problem from
    pset1 of CS50.
*/
#include<cs50.h>
#include<stdio.h>
int main()
{
    int Height=0,i,j,k;
    do{
    printf("Height: ");
    Height=get_int();
    //scanf("%d",&Height);
    if(Height==0)return 0;
    }while(Height<1 || Height>23);
    
    for(i=1;i<=Height;i++)
    {
        for(j=1;j<=Height-i;j++)
        {
            printf("%s"," ");
        }
              for(k=1;k<=i+1;k++)
    {
        printf("#");
    }
       printf("\n");

          }
}