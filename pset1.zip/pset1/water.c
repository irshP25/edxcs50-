/*water.c
    
    Author: Pooja Srivastava
    
    This file is a solution of the water problem from
    pset1 of CS50.
*/
#include<cs50.h>
#include<stdio.h>
int main()
{
    int min;
    printf("minutes: ");
    min=get_int();
    if(min<0)
    {
        printf("Enter the positive numbers for minutes\n");
        
    }
    else
    {
        int bottles=min*12;
        printf("bottles: %d\n", bottles);
        
    }
}