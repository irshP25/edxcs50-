/*caesar.c
    
    Author: Pooja Srivastava
    
    This file is a solution of the caesar problem from
    pset2 of CS50.
*/
#include<cs50.h>
#include<stdio.h>
#include<string.h>
#include<ctype.h>
#include<stdlib.h>

int main(int argc,string argv[])
{
    int key=0;
    //bool keysucces=false;

        if(argc!=2)
        {
            
            printf("Incorrect arguments\n");
            return 1;
        }
            key=atoi(argv[1]);
            if(key<0)
            {printf("Invalid encryption key\n");return 1;}
            else{
        printf("plaintext: ");
        string pt=GetString();
        int len=strlen(pt);
        printf("ciphertext: ");
    for(int i=0;i<len;i++)
     {
        // Encrypts uppercase letter
        if(isupper(pt[i]))
         {printf("%c",(((pt[i]-65)+key)%26)+65);}
             
        //Encrypts lowercase letter
        else if(islower(pt[i]))
         {printf("%c",(((pt[i]-97)+key)%26)+97);}
        
        else
         {printf("%c",pt[i]);}
        
        
     }
    printf("\n");
    
    return 0;
  }}