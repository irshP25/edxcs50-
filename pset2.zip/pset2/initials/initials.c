/*initials.c
    
    Author: Pooja Srivastava
    
    This file is a solution of the initials less comfortable problem from
    pset2 of CS50.
*/
#include<cs50.h>
#include<stdio.h>
#include<string.h>
#include<ctype.h>
int main()
{
    string s=get_string();
    char a;
    //int j=0;
    //printing first initial letter
    a=s[0];
    printf("%c",toupper(a));
    //printing other initial letter
    for(int i=0;i<strlen(s);i++)
    {
        if(s[i]==' ')
        {
            
            
            a=s[i+1];
            printf("%c",toupper(a));
        }
        
    }
    printf("\n");
    
}