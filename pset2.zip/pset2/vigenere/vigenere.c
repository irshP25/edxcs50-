/*vigenere.c
    
    Author: Pooja Srivastava
    
    This file is a solution of the vigenere problem from
    pset2 of CS50.
*/
#include<cs50.h>
#include<stdio.h>
#include<string.h>
#include<ctype.h>
#include<stdlib.h>

int main(int argc,string argv[])
{
    
        if(argc!=2)
        {
            
            printf("Incorrect arguments\n");
            return 1;
        }
        
        else
        
        {
            for(int j=0;j<strlen(argv[1]);j++)
            {
                if(!isalpha(argv[1][j]))
                {printf("Encrytion key is not alphabetic characters\n"); return 1;}
            }
            
        }
          string key=argv[1];
          int keylen=strlen(key);
          printf("plaintext: ");
          string pt=GetString();
          int len=strlen(pt);
          printf("ciphertext: ");
        for(int i=0,j=0;i<len;i++)
        { 
            //get key letter
          int letter=tolower(key[j%keylen])-97;
          // Encrypts uppercase letter
          if(isupper(pt[i]))
          {
              printf("%c",(((pt[i]-65)+letter)%26)+65);
              j++;
          }
             
          //Encrypts lowercase letter
          else if(islower(pt[i]))
          {
              printf("%c",(((pt[i]-97)+letter)%26)+97);
              j++;
          }
        
          else
          { 
              //return unchanged
              printf("%c",pt[i]);
              
          }
        
        
        }
       printf("\n");
    
       return 0;
    }