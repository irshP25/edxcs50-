/**
 * Author: Pooja srivastava
 * Implements a dictionary's functionality.
 */

#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <ctype.h>
#include "dictionary.h"

typedef struct node{
    
    char *word;
    struct node *next;
} node;
int dicsize=0;
char word[LENGTH+1];
node *hashtable[27];
//hash function
int hash(const char* word)
{
    // initialize index to 0
    int index = 0;

    // sum ascii values
    for (int i = 0; word[i] != '\0'; i++)
        // search for lower cases words
        index += tolower(word[i]);

    // mod by size to stay w/in bound of table
    return index % 27;
}
/**
 * Returns true if word is in dictionary else false.
 */
bool check(const char *word)
{
    // memory allocation for checker
    node *checker=malloc(sizeof(node));
    //position of word in bucket
    int bucket=hash(word);
    //situation of word in checker
    checker=hashtable[bucket];
    while (checker != NULL)
    {
        // use strcasecmp to be case insensitive
        if (strcasecmp(checker->word, word) == 0)
            return true;
        checker = checker->next;
    }
    free(checker);
    return false;
}

/**
 * Loads dictionary into memory. Returns true if successful else false.
 */
bool load(const char *dictionary)
{
    
  FILE *dic_open=fopen(dictionary,"r");
  // check dictionry opens properly
  if(dic_open==NULL)return false;
    while(fscanf(dic_open, "%s\n", word)!=EOF)
    { node *new_node = malloc(sizeof(node));

    
        // initiate first pointer
        new_node->word = malloc(strlen(word) + 1);

        // copy word into pointer
        strcpy(new_node->word, word);
         int hash_word = hash(word);
        //if word hashed is found 
        if(hashtable[hash_word]==NULL)
        {
            hashtable[hash_word]=new_node;
            new_node->next=NULL;
        }
        //if lies in middle
        else
        {
            new_node->next=hashtable[hash_word];
            hashtable[hash_word]=new_node;
        }
        dicsize++;

    }
    //free(new_node);
    fclose(dic_open);
    //free(new);
    return true;
}

/**
 * Returns number of words in dictionary if loaded else 0 if not yet loaded.
 */
unsigned int size(void)
{
    // TODO
    return dicsize;
}

/**
 * Unloads dictionary from memory. Returns true if successful else false.
 */
bool unload(void)
{
    for (int k = 0; k < 27; k++)
    {
        // initiate a cursor
        node *cur;

        // place the cursor inside the hashtable
        cur = hashtable[k];

        while (cur)
        {
            node* tmp = cur;
            cur = cur->next;
            free(tmp);
            return true;
        }

        // clean the hashtable
        hashtable[k] = NULL;
    }
    return false;
}
