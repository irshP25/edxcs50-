#caesar.py
    
    #Author: Pooja Srivastava
    
    #This file is a solution of the caesar problem from
    #pset6 of CS50.
#
import cs50
import sys

def main():
    if len(sys.argv) != 2:
        print("Usage: python caesar.py k")
        exit(1)
    
    k = int(sys.argv[1])
    if k<0:
        print("Invalid encryption key",end = "")
        exit(1)
    else:
        print("plaintext: ",end = "")
        ciphertext=[]
        pt=cs50.get_string()
        for i in pt:
            if i.isalpha():
                ciphertext.append(caesar(i, k))
             
        else:
            ciphertext.append(i)
                
    print("ciphertext:","".join(ciphertext))
    exit(0)

def caesar(char, key):
    if char.isupper():
        return chr(((ord(char) - 65 + key) % 26) + 65)
    else:
        return chr(((ord(char) - 97 + key) % 26) + 97)
        
if __name__ == "__main__":
    main()