#greedy.py
    
    #Author: Pooja Srivastava
    
    #This file is a solution of the greedy problem from
    #pset6 of CS50.
#
import cs50

def main():
    while True:
        print("O hai! How much change is owed?")
        amount = cs50.get_float()
        if amount >= 0:
            break
    
    coins = 0
    cents_left = int(round(amount * 100))
    
    coins += cents_left // 25
    cents_left %= 25
    
    coins += cents_left // 10
    cents_left%= 10
    
    coins += cents_left // 5
    cents_left %= 5
    
    coins += cents_left
    
    print("{}".format(coins))
    
if __name__ == "__main__":
    main()