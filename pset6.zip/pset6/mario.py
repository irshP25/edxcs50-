#mario.py
    
    #Author: Pooja Srivastava
    
    #This file is a solution of the mario pyramid problem from
    #pset6 of CS50.
#
import cs50
def main ():
    #Height=0,i,j,k
    i,j,k=1,1,1
    while True:
        print("Height: ",end = "")
        Height=cs50.get_int()
        if Height>=0 and Height<=23:
            break
    for i in range(Height):
        for j in range(Height-i-1):
            print(" ", end = "")
        for k in range(i+2):
            print("#",end = "")
        print("")
if __name__ == "__main__":
    main()        
        
        
        